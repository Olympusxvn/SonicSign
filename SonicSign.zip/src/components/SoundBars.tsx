import React from "react";
import { motion } from "framer-motion";

interface SoundBarsProps {
  active: boolean;
  color?: "cyan" | "magenta" | "success";
  barCount?: number;
}

const colorMap = {
  cyan: "bg-primary",
  magenta: "bg-secondary",
  success: "bg-success",
};

const SoundBars: React.FC<SoundBarsProps> = ({
  active,
  color = "cyan",
  barCount = 5,
}) => {
  return (
    <div className="flex items-center justify-center gap-[3px] h-8">
      {Array.from({ length: barCount }).map((_, i) => (
        <motion.div
          key={i}
          className={`w-[3px] rounded-full ${colorMap[color]}`}
          animate={
            active
              ? {
                  height: ["20%", "100%", "40%", "80%", "20%"],
                }
              : { height: "20%" }
          }
          transition={
            active
              ? {
                  duration: 0.8,
                  repeat: Infinity,
                  delay: i * 0.12,
                  ease: "easeInOut",
                }
              : { duration: 0.3 }
          }
          style={{ height: "20%" }}
        />
      ))}
    </div>
  );
};

export default SoundBars;
