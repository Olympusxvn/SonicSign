import React from "react";
import { Clock, CheckCircle2, XCircle, AlertCircle, ExternalLink } from "lucide-react";
import { TransactionRecord, timeAgo } from "@/lib/transactions";
import { shortenAddress } from "@/lib/solana";

interface TransactionHistoryProps {
  transactions: TransactionRecord[];
}

const statusConfig = {
  success: {
    icon: CheckCircle2,
    color: "text-success",
    bg: "bg-success/10",
    label: "Confirmed",
  },
  cancelled: {
    icon: XCircle,
    color: "text-destructive",
    bg: "bg-destructive/10",
    label: "Cancelled",
  },
  error: {
    icon: AlertCircle,
    color: "text-destructive",
    bg: "bg-destructive/10",
    label: "Failed",
  },
};

const TransactionHistory: React.FC<TransactionHistoryProps> = ({ transactions }) => {
  return (
    <div className="glass-panel rounded-xl p-6">
      <div className="flex items-center gap-2 mb-5">
        <Clock className="w-4 h-4 text-primary" />
        <h2 className="text-lg font-semibold text-foreground">Recent Transactions</h2>
      </div>

      {transactions.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-10 text-muted-foreground">
          <Clock className="w-8 h-8 mb-2 opacity-40" />
          <p className="text-sm">No transactions yet</p>
          <p className="text-xs mt-1 opacity-60">
            Send SOL using voice confirmation to see history here
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {transactions.map((tx) => {
            const config = statusConfig[tx.status];
            const StatusIcon = config.icon;

            return (
              <div
                key={tx.id}
                className="flex items-center gap-3 p-3 rounded-lg bg-background/30 border border-primary/5 hover:border-primary/15 transition-colors"
              >
                <div className={`flex items-center justify-center w-8 h-8 rounded-lg ${config.bg}`}>
                  <StatusIcon className={`w-4 h-4 ${config.color}`} />
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-foreground font-mono">
                      {tx.amount} SOL
                    </span>
                    <span className="text-xs text-muted-foreground">→</span>
                    <span className="text-xs font-mono text-muted-foreground truncate">
                      {shortenAddress(tx.recipient)}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className={`text-xs ${config.color}`}>{config.label}</span>
                    <span className="text-xs text-muted-foreground/60">
                      {timeAgo(tx.timestamp)}
                    </span>
                  </div>
                </div>

                {tx.signature && (
                  <a
                    href={`https://explorer.solana.com/tx/${tx.signature}?cluster=devnet`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center w-7 h-7 rounded-md hover:bg-primary/10 text-primary/60 hover:text-primary transition-colors"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default TransactionHistory;
