import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Volume2, Mic, Loader2, CheckCircle2, XCircle, AlertCircle } from "lucide-react";
import SoundBars from "./SoundBars";
import PulsingMic from "./PulsingMic";

export type VoiceStep =
  | "idle"
  | "speaking"
  | "listening"
  | "processing"
  | "success"
  | "cancelled"
  | "error";

interface VoiceStateDisplayProps {
  step: VoiceStep;
  txSignature?: string | null;
}

const VoiceStateDisplay: React.FC<VoiceStateDisplayProps> = ({ step, txSignature }) => {
  if (step === "idle") return null;

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={step}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -10 }}
        transition={{ duration: 0.3 }}
        className="mt-5"
      >
        {step === "speaking" && (
          <div className="flex flex-col items-center gap-3 p-5 rounded-xl bg-primary/5 border border-primary/20">
            <div className="flex items-center gap-3">
              <Volume2 className="w-5 h-5 text-primary" />
              <SoundBars active barCount={7} color="cyan" />
            </div>
            <p className="text-sm font-medium text-primary">
              AI Reading Transaction Details...
            </p>
          </div>
        )}

        {step === "listening" && (
          <div className="flex flex-col items-center gap-3 p-5 rounded-xl bg-secondary/5 border border-secondary/20">
            <PulsingMic active />
            <p className="text-sm font-medium text-secondary">
              Say <span className="font-bold">"CONFIRM"</span> or{" "}
              <span className="font-bold">"CANCEL"</span>
            </p>
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Mic className="w-3 h-3" />
              <span>Listening for 8 seconds...</span>
            </div>
          </div>
        )}

        {step === "processing" && (
          <div className="flex flex-col items-center gap-3 p-5 rounded-xl bg-primary/5 border border-primary/20">
            <Loader2 className="w-8 h-8 text-primary animate-spin" />
            <p className="text-sm font-medium text-primary">
              Submitting to Solana Devnet...
            </p>
          </div>
        )}

        {step === "success" && (
          <div className="flex flex-col items-center gap-3 p-5 rounded-xl bg-success/5 border border-success/20 animate-pulse-success">
            <CheckCircle2 className="w-8 h-8 text-success" />
            <p className="text-sm font-medium text-success">
              Transaction Confirmed
            </p>
            {txSignature && (
              <a
                href={`https://explorer.solana.com/tx/${txSignature}?cluster=devnet`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs font-mono text-primary hover:text-primary/80 underline underline-offset-2 transition-colors"
              >
                {txSignature.slice(0, 16)}...{txSignature.slice(-8)} ↗
              </a>
            )}
          </div>
        )}

        {step === "cancelled" && (
          <div className="flex flex-col items-center gap-3 p-5 rounded-xl bg-destructive/5 border border-destructive/20">
            <XCircle className="w-8 h-8 text-destructive" />
            <p className="text-sm font-medium text-destructive">
              Transaction Aborted by Voice
            </p>
          </div>
        )}

        {step === "error" && (
          <div className="flex flex-col items-center gap-3 p-5 rounded-xl bg-destructive/5 border border-destructive/20">
            <AlertCircle className="w-8 h-8 text-destructive" />
            <p className="text-sm font-medium text-destructive">
              Something went wrong. Please try again.
            </p>
          </div>
        )}
      </motion.div>
    </AnimatePresence>
  );
};

export default VoiceStateDisplay;
