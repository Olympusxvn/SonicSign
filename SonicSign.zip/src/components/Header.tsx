import React from "react";
import { Link, useLocation } from "react-router-dom";
import { Volume2 } from "lucide-react";
import { WalletMultiButton } from "@solana/wallet-adapter-react-ui";

const Header: React.FC = () => {
  const location = useLocation();
  const isApp = location.pathname === "/app";

  return (
    <header className="fixed top-0 left-0 right-0 z-50 glass-panel border-b border-primary/15">
      <div className="container mx-auto flex items-center justify-between h-16 px-4 md:px-6">
        <Link to="/" className="flex items-center gap-2 group">
          <div className="relative flex items-center justify-center w-8 h-8 rounded-lg bg-primary/10 border border-primary/30 group-hover:border-primary/60 transition-all">
            <Volume2 className="w-4 h-4 text-primary" />
          </div>
          <span className="text-lg font-bold tracking-tight text-foreground">
            Sonic<span className="text-primary">Sign</span>
          </span>
        </Link>

        <nav className="flex items-center gap-3">
          {isApp ? (
            <span className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1 text-xs font-mono rounded-md bg-primary/10 border border-primary/20 text-primary">
              <span className="w-1.5 h-1.5 rounded-full bg-primary animate-glow-pulse" />
              Devnet
            </span>
          ) : (
            <Link
              to="/app"
              className="hidden sm:inline-flex items-center px-4 py-2 text-sm font-medium rounded-lg bg-muted text-foreground hover:bg-muted/80 border border-primary/10 hover:border-primary/30 transition-all"
            >
              Launch App
            </Link>
          )}
          <WalletMultiButton />
        </nav>
      </div>
    </header>
  );
};

export default Header;
