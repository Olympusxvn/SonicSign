import React, { useState, useEffect } from "react";
import { Key, Eye, EyeOff, Check } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

interface ApiKeyInputProps {
  apiKey: string;
  onApiKeyChange: (key: string) => void;
}

const STORAGE_KEY = "sonicsign_elevenlabs_key";

const ApiKeyInput: React.FC<ApiKeyInputProps> = ({ apiKey, onApiKeyChange }) => {
  const [visible, setVisible] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      onApiKeyChange(stored);
    }
  }, [onApiKeyChange]);

  const handleSave = () => {
    localStorage.setItem(STORAGE_KEY, apiKey);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="glass-panel rounded-xl p-6">
      <div className="flex items-center gap-2 mb-3">
        <Key className="w-4 h-4 text-primary" />
        <h3 className="text-sm font-semibold text-foreground">ElevenLabs API Key</h3>
      </div>
      <p className="text-xs text-muted-foreground mb-3">
        Enter your API key for AI voice. Falls back to browser TTS if empty.
      </p>
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Input
            type={visible ? "text" : "password"}
            placeholder="xi_..."
            value={apiKey}
            onChange={(e) => onApiKeyChange(e.target.value)}
            className="bg-background/50 border-primary/15 text-foreground font-mono text-xs placeholder:text-muted-foreground/40 focus:border-primary/40 pr-9"
          />
          <button
            type="button"
            onClick={() => setVisible(!visible)}
            className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
          >
            {visible ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
          </button>
        </div>
        <Button
          onClick={handleSave}
          variant="outline"
          size="sm"
          className="border-primary/20 text-primary hover:bg-primary/10 hover:text-primary"
        >
          {saved ? <Check className="w-3.5 h-3.5" /> : "Save"}
        </Button>
      </div>
    </div>
  );
};

export default ApiKeyInput;
