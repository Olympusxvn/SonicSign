import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Mic } from "lucide-react";

interface PulsingMicProps {
  active: boolean;
}

const PulsingMic: React.FC<PulsingMicProps> = ({ active }) => {
  return (
    <div className="relative flex items-center justify-center w-16 h-16">
      <AnimatePresence>
        {active && (
          <>
            {[0, 1, 2].map((i) => (
              <motion.div
                key={i}
                className="absolute inset-0 rounded-full border-2 border-secondary"
                initial={{ scale: 0.8, opacity: 1 }}
                animate={{ scale: 2.2, opacity: 0 }}
                transition={{
                  duration: 1.8,
                  repeat: Infinity,
                  delay: i * 0.6,
                  ease: "easeOut",
                }}
              />
            ))}
          </>
        )}
      </AnimatePresence>

      <motion.div
        className={`relative z-10 flex items-center justify-center w-12 h-12 rounded-full ${
          active
            ? "bg-secondary/20 border-2 border-secondary"
            : "bg-muted border-2 border-muted-foreground/30"
        }`}
        animate={active ? { scale: [1, 1.1, 1] } : { scale: 1 }}
        transition={
          active
            ? { duration: 1, repeat: Infinity, ease: "easeInOut" }
            : { duration: 0.3 }
        }
      >
        <Mic
          className={`w-5 h-5 ${active ? "text-secondary" : "text-muted-foreground"}`}
        />
      </motion.div>
    </div>
  );
};

export default PulsingMic;
