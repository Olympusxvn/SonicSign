import React, { useState, useCallback } from "react";
import { useWallet } from "@solana/wallet-adapter-react";
import { Mic, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { speakTransactionPrompt } from "@/lib/elevenlabs";
import { listenForConfirmation } from "@/lib/speechRecognition";
import { sendSOL, isValidSolanaAddress } from "@/lib/solana";
import { addTransaction, TransactionRecord } from "@/lib/transactions";
import VoiceStateDisplay, { VoiceStep } from "./VoiceStateDisplay";
import { useToast } from "@/hooks/use-toast";

interface SendPanelProps {
  onBalanceChange: () => void;
  onNewTransaction: (tx: TransactionRecord) => void;
  apiKey: string;
}

const SendPanel: React.FC<SendPanelProps> = ({
  onBalanceChange,
  onNewTransaction,
  apiKey,
}) => {
  const { publicKey, signTransaction } = useWallet();
  const { toast } = useToast();
  const [recipient, setRecipient] = useState("");
  const [amount, setAmount] = useState("");
  const [step, setStep] = useState<VoiceStep>("idle");
  const [txSignature, setTxSignature] = useState<string | null>(null);

  const resetState = useCallback(() => {
    setTimeout(() => {
      setStep("idle");
      setTxSignature(null);
    }, 5000);
  }, []);

  const handleVoiceConfirm = useCallback(async () => {
    if (!publicKey || !signTransaction) {
      toast({
        title: "Wallet not connected",
        description: "Please connect your Phantom wallet first.",
        variant: "destructive",
      });
      return;
    }

    const amountNum = parseFloat(amount);
    if (!amount || isNaN(amountNum) || amountNum <= 0) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid SOL amount.",
        variant: "destructive",
      });
      return;
    }

    if (!recipient || !isValidSolanaAddress(recipient)) {
      toast({
        title: "Invalid address",
        description: "Please enter a valid Solana address.",
        variant: "destructive",
      });
      return;
    }

    try {
      // Step 1: ElevenLabs speaks transaction details
      setStep("speaking");
      await speakTransactionPrompt(amountNum, recipient, apiKey);

      // Step 2: Listen for user's voice response
      setStep("listening");
      const result = await listenForConfirmation();

      if (result !== "confirm") {
        setStep("cancelled");
        const tx = addTransaction({
          recipient,
          amount: amountNum,
          status: "cancelled",
        });
        onNewTransaction(tx);
        toast({
          title: "Transaction Cancelled",
          description: "Voice command: cancel / timeout",
        });
        resetState();
        return;
      }

      // Step 3: Submit transaction
      setStep("processing");
      const sig = await sendSOL(publicKey, recipient, amountNum, signTransaction);
      setTxSignature(sig);
      setStep("success");

      const tx = addTransaction({
        recipient,
        amount: amountNum,
        status: "success",
        signature: sig,
      });
      onNewTransaction(tx);
      onBalanceChange();

      toast({
        title: "Transaction Successful",
        description: `Sent ${amountNum} SOL`,
      });

      setRecipient("");
      setAmount("");
      resetState();
    } catch (err) {
      console.error("Transaction error:", err);
      setStep("error");

      const tx = addTransaction({
        recipient,
        amount: amountNum,
        status: "error",
      });
      onNewTransaction(tx);

      toast({
        title: "Transaction Failed",
        description: err instanceof Error ? err.message : "Unknown error",
        variant: "destructive",
      });
      resetState();
    }
  }, [publicKey, signTransaction, amount, recipient, apiKey, toast, onBalanceChange, onNewTransaction, resetState]);

  const isDisabled = step !== "idle" && step !== "success" && step !== "cancelled" && step !== "error";

  return (
    <div className="glass-panel rounded-xl p-6">
      <div className="flex items-center gap-2 mb-5">
        <Send className="w-4 h-4 text-primary" />
        <h2 className="text-lg font-semibold text-foreground">Send SOL</h2>
      </div>

      <div className="space-y-4">
        <div className="space-y-2">
          <Label className="text-sm text-muted-foreground">Recipient Address</Label>
          <Input
            placeholder="Enter Solana address..."
            value={recipient}
            onChange={(e) => setRecipient(e.target.value)}
            disabled={isDisabled}
            className="bg-background/50 border-primary/15 text-foreground font-mono text-sm placeholder:text-muted-foreground/50 focus:border-primary/40 focus:ring-primary/20"
          />
        </div>

        <div className="space-y-2">
          <Label className="text-sm text-muted-foreground">Amount (SOL)</Label>
          <Input
            type="number"
            step="0.01"
            min="0"
            placeholder="0.00"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            disabled={isDisabled}
            className="bg-background/50 border-primary/15 text-foreground font-mono text-sm placeholder:text-muted-foreground/50 focus:border-primary/40 focus:ring-primary/20"
          />
        </div>

        <Button
          onClick={handleVoiceConfirm}
          disabled={isDisabled || !publicKey}
          className="w-full h-12 bg-gradient-to-r from-primary to-secondary text-primary-foreground font-semibold text-sm tracking-wide hover:opacity-90 transition-all disabled:opacity-40 disabled:cursor-not-allowed"
        >
          <Mic className="w-4 h-4 mr-2" />
          VOICE CONFIRM
        </Button>
      </div>

      <VoiceStateDisplay step={step} txSignature={txSignature} />
    </div>
  );
};

export default SendPanel;
