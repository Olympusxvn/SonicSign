import React, { useState, useEffect, useCallback } from "react";
import { useWallet, useConnection } from "@solana/wallet-adapter-react";
import { LAMPORTS_PER_SOL } from "@solana/web3.js";
import { Wallet, RefreshCw, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { requestAirdrop, shortenAddress } from "@/lib/solana";
import { useToast } from "@/hooks/use-toast";

interface BalanceCardProps {
  refreshTrigger: number;
}

const BalanceCard: React.FC<BalanceCardProps> = ({ refreshTrigger }) => {
  const { publicKey } = useWallet();
  const { connection } = useConnection();
  const { toast } = useToast();
  const [balance, setBalance] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [airdropping, setAirdropping] = useState(false);

  const fetchBalance = useCallback(async () => {
    if (!publicKey) {
      setBalance(null);
      return;
    }
    setLoading(true);
    try {
      const bal = await connection.getBalance(publicKey);
      setBalance(bal / LAMPORTS_PER_SOL);
    } catch {
      console.error("Failed to fetch balance");
    } finally {
      setLoading(false);
    }
  }, [publicKey, connection]);

  useEffect(() => {
    fetchBalance();
  }, [fetchBalance, refreshTrigger]);

  const handleAirdrop = async () => {
    if (!publicKey) return;
    setAirdropping(true);
    try {
      await requestAirdrop(publicKey);
      toast({
        title: "Airdrop Successful",
        description: "Received 2 SOL on Devnet",
      });
      fetchBalance();
    } catch (err) {
      toast({
        title: "Airdrop Failed",
        description: err instanceof Error ? err.message : "Try again later",
        variant: "destructive",
      });
    } finally {
      setAirdropping(false);
    }
  };

  if (!publicKey) return null;

  return (
    <div className="glass-panel rounded-xl p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Wallet className="w-4 h-4 text-primary" />
          <span className="text-sm text-muted-foreground">Connected Wallet</span>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={fetchBalance}
          disabled={loading}
          className="text-muted-foreground hover:text-primary h-7 px-2"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
        </Button>
      </div>

      <p className="font-mono text-xs text-primary/80 mb-4 truncate">
        {shortenAddress(publicKey.toBase58(), 8)}
      </p>

      <div className="flex items-baseline gap-2 mb-5">
        <span className="text-3xl font-bold text-foreground font-mono">
          {balance !== null ? balance.toFixed(4) : "—"}
        </span>
        <span className="text-sm text-muted-foreground">SOL</span>
      </div>

      <Button
        onClick={handleAirdrop}
        disabled={airdropping}
        variant="outline"
        className="w-full border-primary/20 text-primary hover:bg-primary/10 hover:text-primary"
      >
        <Download className="w-4 h-4 mr-2" />
        {airdropping ? "Requesting..." : "Get Devnet SOL"}
      </Button>
    </div>
  );
};

export default BalanceCard;
