export interface TransactionRecord {
  id: string;
  recipient: string;
  amount: number;
  status: "success" | "cancelled" | "error";
  signature?: string;
  timestamp: number;
}

const STORAGE_KEY = "sonicsign_tx_history";

export function getTransactionHistory(): TransactionRecord[] {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function addTransaction(tx: Omit<TransactionRecord, "id" | "timestamp">): TransactionRecord {
  const record: TransactionRecord = {
    ...tx,
    id: crypto.randomUUID(),
    timestamp: Date.now(),
  };

  const history = getTransactionHistory();
  history.unshift(record);
  
  // Keep only last 20 transactions
  const trimmed = history.slice(0, 20);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(trimmed));
  
  return record;
}

export function timeAgo(timestamp: number): string {
  const seconds = Math.floor((Date.now() - timestamp) / 1000);
  
  if (seconds < 10) return "just now";
  if (seconds < 60) return `${seconds}s ago`;
  
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}
