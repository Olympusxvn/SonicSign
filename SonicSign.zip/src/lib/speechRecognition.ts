export type VoiceResult = "confirm" | "cancel" | "timeout";

interface SpeechRecognitionEvent {
  results: {
    [index: number]: {
      [index: number]: {
        transcript: string;
        confidence: number;
      };
    };
  };
}

export function listenForConfirmation(): Promise<VoiceResult> {
  return new Promise((resolve) => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      console.warn("SpeechRecognition not supported in this browser");
      resolve("timeout");
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = "en-US";
    recognition.maxAlternatives = 3;
    recognition.continuous = false;
    recognition.interimResults = false;

    const timer = setTimeout(() => {
      recognition.stop();
      resolve("timeout");
    }, 8000);

    recognition.onresult = (event: SpeechRecognitionEvent) => {
      clearTimeout(timer);
      const transcript = event.results[0][0].transcript.toLowerCase().trim();
      if (transcript.includes("confirm") || transcript.includes("yes") || transcript.includes("send")) {
        resolve("confirm");
      } else {
        resolve("cancel");
      }
    };

    recognition.onerror = () => {
      clearTimeout(timer);
      resolve("cancel");
    };

    recognition.onnomatch = () => {
      clearTimeout(timer);
      resolve("cancel");
    };

    recognition.start();
  });
}

export function isSpeechRecognitionSupported(): boolean {
  return !!(
    (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
  );
}
