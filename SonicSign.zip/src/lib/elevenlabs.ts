const VOICE_ID = "21m00Tcm4TlvDq8ikWAM"; // Rachel — clear, authoritative

export async function speakTransactionPrompt(
  amount: number,
  recipientAddress: string,
  apiKey: string
): Promise<void> {
  const shortAddress = `${recipientAddress.slice(0, 4)}...${recipientAddress.slice(-4)}`;
  const text = `You are about to send ${amount} SOL to address ${shortAddress}. This action is irreversible. Say confirm to proceed, or cancel to abort.`;

  if (!apiKey) {
    // Fallback to browser TTS if no API key
    return speakWithBrowserTTS(text);
  }

  try {
    const response = await fetch(
      `https://api.elevenlabs.io/v1/text-to-speech/${VOICE_ID}`,
      {
        method: "POST",
        headers: {
          "xi-api-key": apiKey,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          text,
          model_id: "eleven_monolingual_v1",
          voice_settings: { stability: 0.75, similarity_boost: 0.85 },
        }),
      }
    );

    if (!response.ok) {
      console.warn("ElevenLabs API failed, falling back to browser TTS");
      return speakWithBrowserTTS(text);
    }

    const audioBlob = await response.blob();
    const audioUrl = URL.createObjectURL(audioBlob);
    const audio = new Audio(audioUrl);
    await audio.play();

    await new Promise<void>((resolve) => {
      audio.onended = () => {
        URL.revokeObjectURL(audioUrl);
        resolve();
      };
    });
  } catch {
    return speakWithBrowserTTS(text);
  }
}

function speakWithBrowserTTS(text: string): Promise<void> {
  return new Promise((resolve) => {
    if (!window.speechSynthesis) {
      resolve();
      return;
    }
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.95;
    utterance.pitch = 1;
    utterance.onend = () => resolve();
    utterance.onerror = () => resolve();
    window.speechSynthesis.speak(utterance);
  });
}
