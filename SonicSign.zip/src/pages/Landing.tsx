import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Volume2, Shield, Mic, ArrowRight, Zap, Lock, Ear } from "lucide-react";
import { Button } from "@/components/ui/button";
import Header from "@/components/Header";
import SoundBars from "@/components/SoundBars";

const features = [
  {
    icon: Ear,
    title: "Voice Confirmation",
    description: "Every transaction is read aloud before execution. You hear exactly what you're signing.",
  },
  {
    icon: Shield,
    title: "Anti-Phishing Shield",
    description:
      "Can't silently hijack a voice confirmation. Social engineering attacks are neutralized.",
  },
  {
    icon: Lock,
    title: "Fat-Finger Protection",
    description: "Wrong amount or address? You'll hear the mistake before it becomes irreversible.",
  },
  {
    icon: Zap,
    title: "Instant on Devnet",
    description: "Built on Solana for sub-second finality. Voice confirm, and it's done.",
  },
];

const Landing: React.FC = () => {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden">
      <Header />

      {/* Hero */}
      <section className="relative flex flex-col items-center justify-center min-h-screen pt-16 px-4">
        {/* Background grid */}
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `linear-gradient(hsl(187 100% 50%) 1px, transparent 1px), linear-gradient(90deg, hsl(187 100% 50%) 1px, transparent 1px)`,
            backgroundSize: "60px 60px",
          }}
        />

        {/* Radial glow */}
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-primary/5 blur-[120px] pointer-events-none" />
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] h-[300px] rounded-full bg-secondary/5 blur-[80px] pointer-events-none" />

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="relative z-10 flex flex-col items-center text-center max-w-3xl mx-auto"
        >
          {/* Logo orb */}
          <motion.div
            className="relative mb-8 animate-float"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.6 }}
          >
            <div className="flex items-center justify-center w-20 h-20 rounded-2xl bg-primary/10 border border-primary/30 animate-pulse-cyan">
              <Volume2 className="w-9 h-9 text-primary" />
            </div>
          </motion.div>

          <motion.h1
            className="text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight mb-5"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.6 }}
          >
            <span className="text-foreground">Your voice confirms</span>
            <br />
            <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              every transaction.
            </span>
          </motion.h1>

          <motion.p
            className="text-lg sm:text-xl text-muted-foreground mb-8 max-w-xl leading-relaxed"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.45, duration: 0.6 }}
          >
            No click. No doubt. SonicSign reads your Solana transaction aloud
            and waits for your spoken confirmation before signing.
          </motion.p>

          {/* Sound bars accent */}
          <motion.div
            className="mb-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6, duration: 0.5 }}
          >
            <SoundBars active barCount={9} color="cyan" />
          </motion.div>

          <motion.div
            className="flex flex-col sm:flex-row items-center gap-3"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.65, duration: 0.6 }}
          >
            <Link to="/app">
              <Button className="h-12 px-8 bg-gradient-to-r from-primary to-secondary text-primary-foreground font-semibold text-base hover:opacity-90 transition-all shadow-lg">
                Launch App
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
            <a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
            >
              <Button
                variant="outline"
                className="h-12 px-8 border-primary/20 text-foreground hover:bg-primary/5 hover:border-primary/40 font-medium"
              >
                View Source
              </Button>
            </a>
          </motion.div>
        </motion.div>

        {/* Scroll indicator */}
        <motion.div
          className="absolute bottom-8 left-1/2 -translate-x-1/2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2, duration: 0.5 }}
        >
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="w-5 h-8 rounded-full border-2 border-primary/30 flex items-start justify-center pt-1.5"
          >
            <div className="w-1 h-1.5 rounded-full bg-primary" />
          </motion.div>
        </motion.div>
      </section>

      {/* Features */}
      <section className="relative py-24 px-4">
        <div className="container mx-auto max-w-5xl">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl sm:text-4xl font-bold mb-4 text-foreground">
              Why Voice Confirmation?
            </h2>
            <p className="text-muted-foreground text-lg max-w-xl mx-auto">
              You can steal a private key. You can clone a passphrase. But you
              can't silently hijack a voice confirmation in real-time.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
                className="glass-panel glass-panel-hover rounded-xl p-6 transition-all"
              >
                <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-primary/10 border border-primary/20 mb-4">
                  <feature.icon className="w-5 h-5 text-primary" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  {feature.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="relative py-24 px-4 border-t border-primary/10">
        <div className="container mx-auto max-w-3xl">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl sm:text-4xl font-bold mb-4 text-foreground">
              How It Works
            </h2>
          </motion.div>

          <div className="space-y-6">
            {[
              { num: "01", label: "Connect your Phantom wallet", icon: "🔗" },
              { num: "02", label: "Enter recipient address and amount", icon: "✍️" },
              { num: "03", label: "Click Voice Confirm — AI reads it aloud", icon: "🔊" },
              { num: "04", label: 'Say "confirm" — transaction signs and submits', icon: "🎤" },
            ].map((step, i) => (
              <motion.div
                key={step.num}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.5 }}
                className="flex items-center gap-5 p-5 rounded-xl glass-panel glass-panel-hover"
              >
                <span className="text-2xl font-bold font-mono text-primary/40">
                  {step.num}
                </span>
                <span className="text-foreground font-medium">{step.label}</span>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-primary/10 py-10 px-4">
        <div className="container mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Volume2 className="w-4 h-4 text-primary" />
            <span className="text-sm font-semibold text-foreground">
              Sonic<span className="text-primary">Sign</span>
            </span>
          </div>
          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            <span>Built with</span>
            <span className="text-primary font-medium">Solana</span>
            <span className="text-muted-foreground/40">·</span>
            <span className="text-secondary font-medium">ElevenLabs</span>
            <span className="text-muted-foreground/40">·</span>
            <span className="text-foreground font-medium">Phantom</span>
          </div>
          <p className="text-xs text-muted-foreground">
            Dev3pack Global Hackathon 2026
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Landing;
