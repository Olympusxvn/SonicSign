import React, { useState, useCallback, useEffect } from "react";
import { useWallet } from "@solana/wallet-adapter-react";
import { motion } from "framer-motion";
import { Volume2, Wallet } from "lucide-react";
import { WalletMultiButton } from "@solana/wallet-adapter-react-ui";
import Header from "@/components/Header";
import BalanceCard from "@/components/BalanceCard";
import SendPanel from "@/components/SendPanel";
import TransactionHistory from "@/components/TransactionHistory";
import ApiKeyInput from "@/components/ApiKeyInput";
import { TransactionRecord, getTransactionHistory } from "@/lib/transactions";

const Dashboard: React.FC = () => {
  const { connected } = useWallet();
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [transactions, setTransactions] = useState<TransactionRecord[]>([]);
  const [apiKey, setApiKey] = useState("");

  useEffect(() => {
    setTransactions(getTransactionHistory());
  }, []);

  const handleBalanceChange = useCallback(() => {
    setRefreshTrigger((prev) => prev + 1);
  }, []);

  const handleNewTransaction = useCallback((tx: TransactionRecord) => {
    setTransactions((prev) => [tx, ...prev].slice(0, 20));
  }, []);

  if (!connected) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <Header />
        <div className="flex flex-col items-center justify-center min-h-screen px-4">
          {/* Background effects */}
          <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] rounded-full bg-primary/5 blur-[100px] pointer-events-none" />

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="relative z-10 flex flex-col items-center text-center"
          >
            <div className="flex items-center justify-center w-16 h-16 rounded-2xl bg-primary/10 border border-primary/30 mb-6 animate-pulse-cyan">
              <Wallet className="w-7 h-7 text-primary" />
            </div>
            <h1 className="text-2xl font-bold text-foreground mb-2">
              Connect Your Wallet
            </h1>
            <p className="text-muted-foreground mb-6 max-w-sm">
              Connect your Phantom wallet to start sending SOL with voice
              confirmation on Devnet.
            </p>
            <WalletMultiButton />
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />

      {/* Background */}
      <div
        className="fixed inset-0 opacity-[0.02] pointer-events-none"
        style={{
          backgroundImage: `linear-gradient(hsl(187 100% 50%) 1px, transparent 1px), linear-gradient(90deg, hsl(187 100% 50%) 1px, transparent 1px)`,
          backgroundSize: "60px 60px",
        }}
      />

      <main className="relative z-10 pt-24 pb-12 px-4">
        <div className="container mx-auto max-w-5xl">
          {/* Page title */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="flex items-center gap-3 mb-8"
          >
            <div className="flex items-center justify-center w-9 h-9 rounded-lg bg-primary/10 border border-primary/20">
              <Volume2 className="w-4.5 h-4.5 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground">Dashboard</h1>
              <p className="text-xs text-muted-foreground">
                Voice-confirmed SOL transfers on Devnet
              </p>
            </div>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            {/* Left column */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1, duration: 0.5 }}
              className="lg:col-span-2 space-y-5"
            >
              <SendPanel
                onBalanceChange={handleBalanceChange}
                onNewTransaction={handleNewTransaction}
                apiKey={apiKey}
              />
              <TransactionHistory transactions={transactions} />
            </motion.div>

            {/* Right column */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.5 }}
              className="space-y-5"
            >
              <BalanceCard refreshTrigger={refreshTrigger} />
              <ApiKeyInput apiKey={apiKey} onApiKeyChange={setApiKey} />

              {/* Info panel */}
              <div className="glass-panel rounded-xl p-6">
                <h3 className="text-sm font-semibold text-foreground mb-3">
                  How Voice Confirm Works
                </h3>
                <ol className="space-y-2 text-xs text-muted-foreground">
                  <li className="flex gap-2">
                    <span className="text-primary font-mono font-bold">1.</span>
                    <span>Fill in recipient and amount</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary font-mono font-bold">2.</span>
                    <span>Click "Voice Confirm" button</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary font-mono font-bold">3.</span>
                    <span>AI reads transaction details aloud</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary font-mono font-bold">4.</span>
                    <span>Say "confirm" or "cancel"</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-primary font-mono font-bold">5.</span>
                    <span>Transaction signs and submits to Devnet</span>
                  </li>
                </ol>
              </div>
            </motion.div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
