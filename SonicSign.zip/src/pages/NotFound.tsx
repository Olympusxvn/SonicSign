import React from "react";
import { Link } from "react-router-dom";
import { Volume2, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

const NotFound: React.FC = () => {
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col items-center justify-center px-4">
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] h-[300px] rounded-full bg-destructive/5 blur-[100px] pointer-events-none" />

      <div className="relative z-10 flex flex-col items-center text-center">
        <div className="flex items-center justify-center w-14 h-14 rounded-2xl bg-primary/10 border border-primary/30 mb-6">
          <Volume2 className="w-6 h-6 text-primary" />
        </div>

        <h1 className="text-6xl font-bold font-mono text-primary mb-2">404</h1>
        <p className="text-lg text-muted-foreground mb-8">
          This frequency doesn't exist.
        </p>

        <Link to="/">
          <Button
            variant="outline"
            className="border-primary/20 text-foreground hover:bg-primary/5 hover:border-primary/40"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </Link>
      </div>
    </div>
  );
};

export default NotFound;
